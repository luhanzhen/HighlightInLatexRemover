# 使用方法

把你的包含了\hl{ }这样的内容的tex复制到input.tex中，运行程序，在output.tex中复制结果即可。

参数 HighlightInLatexRemover.exe  input.tex  output.tex
注意空格隔开，如果不输入输出的文件名，默认输出到标准输出。